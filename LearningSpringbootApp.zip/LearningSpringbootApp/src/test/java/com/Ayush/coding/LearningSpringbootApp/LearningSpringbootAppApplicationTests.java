package com.Ayush.coding.LearningSpringbootApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearningSpringbootAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
