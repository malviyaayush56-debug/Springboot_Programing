package com.codingayush.InternalWorkingOfSpringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InternalWorkingOfSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
