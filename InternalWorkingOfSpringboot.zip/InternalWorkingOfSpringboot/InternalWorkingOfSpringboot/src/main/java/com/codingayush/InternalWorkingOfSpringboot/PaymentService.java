package com.codingayush.InternalWorkingOfSpringboot;

public interface PaymentService {
    String pay();
}




