package com.codingayush.InternalWorkingOfSpringboot;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InternalWorkingOfSpringbootApplication implements CommandLineRunner {

    private final RazorPaymentService paymentService;

    // Constructor Injection (Best Practice)
    public InternalWorkingOfSpringbootApplication(RazorPaymentService paymentService) {
        this.paymentService = paymentService;
    }

    public static void main(String[] args) {
        SpringApplication.run(InternalWorkingOfSpringbootApplication.class, args);
    }

    @Override
    public void run(String... args) {
        String payment = paymentService.pay();
        System.out.println("Payment done: " + payment);
    }
}